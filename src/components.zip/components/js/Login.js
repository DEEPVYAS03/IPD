import React, { useState } from 'react'
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import '../css/login.css'
import PasswordInput from './PasswordInput';



function Login() {
  const [values, setValues] = useState({
    email: '',
    password: ''
  })


  const handleSubmit =(event)=>{
    event.preventDefault();
    
  }

  const handleInput =(event)=>{
    setValues(prev => ({...prev,[event.target.name]:[event.target.value]}))
  }

  return (
    <div className='container'>
      <div className="form login">

        <form action="" onSubmit={handleSubmit}>
          <span className="title">Login</span>
          <span>
            <select className="login-dropdown">
              <option value="login-Admin" id="login-Admin">Admin</option>
              <option value="login-Candidate" id="login-Candidate">Candidate</option>
              <option value="login-Mock_Candidate" id="login-Mock_Candidate">Mock Candidate</option>
            </select>
          </span>

          <div className="input-field">
            <input type="text" placeholder="Enter your email" required onChange={handleInput} />
            <i className="uil uil-envelope icon"></i>
          </div>


          <PasswordInput onChange={handleInput}/>

          <div className="checkbox-text">
            <div className="checkbox-content">
              <input type="checkbox" id="logCheck" />
              <label htmlFor="logCheck" className="text">Remember me</label>
            </div>

            <a href="#" className="text">Forgot password?</a>
          </div>

          <div className="input-field button">
            <button type="submit">Login</button>
          </div>

        </form>

        <div className="login-signup">
          <span className="text">Not a member?
            <Link to="/register" className="text signup-link">Signup Now</Link>
          </span>
        </div>
      </div>
    </div>
  )
}

export default Login
