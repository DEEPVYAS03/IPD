import React, { useState } from 'react';
import { UilEyeSlash, UilEye, UilLock } from '../css/unicons-react';
import '../css/PasswordInput.css'; 

const PasswordInput = ({ userType, onChange, name, passwordError }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [inputFocused, setInputFocused] = useState(false);
  const [inputValid, setInputValid] = useState(false);

  const togglePasswordVisibility = () => setShowPassword(!showPassword);

  const handleInputFocus = () => {
    setInputFocused(true);
  };

  const handleInputBlur = () => {
    setInputFocused(false);
  };

  const handleInputChange = (e) => {
    setInputValid(e.target.checkValidity());
  };

  return (
    <div className={`input-field ${inputFocused || inputValid ? 'focused' : ''}`}>
      <input
        type={userType === 'reg-Admin' && !showPassword ? 'text' : 'password'}
        className="password"
        name={name}
        placeholder={userType === 'reg-Admin' && !showPassword ? "Enter Company's Password" : "Enter Company's Password"}
        required
        onFocus={handleInputFocus}
        onBlur={handleInputBlur}
        onChange={handleInputChange}
      />
      <i className={`icon ${inputFocused || inputValid ? 'focused' : ''}`}>
        <UilLock />
      </i>
      <i
        className={`showHidePw ${inputFocused || inputValid ? 'focused' : ''}`}
        onClick={togglePasswordVisibility}
      >
        {showPassword ? <UilEyeSlash /> : <UilEye />}
      </i>
      {passwordError && <span className='error'>{passwordError}</span>} {/* Display password error */}
    </div>
  );
};

export default PasswordInput;
