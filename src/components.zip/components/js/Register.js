import React from 'react'
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom'
import '../css/login.css'
import PasswordInput from './PasswordInput'
import { useState } from 'react'


function Register() {
    const [selectedOption, setSelectedOption] = useState('reg-Candidate'); // Default option

    const handleSelectChange = (e) => {
        setSelectedOption(e.target.value);
    };
    return (
        <div className='container reg-container'>
            <div className="form signup">


                <form action="#">
                    <span className="title">Registration</span>
                    <span>
                        <select className="reg-dropdown" onChange={handleSelectChange} value={selectedOption}>
                            <option value="reg-Admin" id="reg-Admin">Admin</option>
                            <option value="reg-Candidate" id="reg-Candidate">Candidate</option>
                            <option value="reg-Mock_Candidate" id="reg-Mock_Candidate">Mock Candidate</option>
                        </select>
                    </span>
                    <div className="input-field">
                        <input type="text" placeholder="Enter your name" required />
                        <i className="uil uil-user"></i>
                    </div>
                    <div className="input-field">
                        <input type="text" placeholder="Enter your email" required />
                        <i className="uil uil-envelope icon"></i>
                    </div>
                    {selectedOption !== 'reg-Admin' && (
                        <div className="input-field">
                            <input
                                type="password"
                                className="password"
                                placeholder="Create a password"
                                required
                            />
                            <i className="uil uil-lock icon"></i>
                        </div>
                    )}
                    <PasswordInput userType={selectedOption} />


                    <div className="checkbox-text">
                        <div className="checkbox-content">
                            <input type="checkbox" id="termCon" />
                            <label htmlFor="termCon" className="text">I accepted all terms and conditions</label>
                        </div>
                    </div>

                    <div className="input-field button">
                        <input type="button" value="Signup" />
                    </div>
                </form>

                <div className="login-signup">
                    <span className="text">Already a member?
                        <Link to="/" className="text login-link">Login Now</Link>
                    </span>
                </div>
            </div>
        </div>


    )
}

export default Register
