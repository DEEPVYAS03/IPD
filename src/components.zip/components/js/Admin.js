import React from 'react'

function Admin() {
  return (
    <div>
      Admin Page
    </div>
  )
}

export default Admin
