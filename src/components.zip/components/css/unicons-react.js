import React from 'react'
import './PasswordInput.css'

export  function UilEyeSlash() {
  return (
    <i className='uil uil-eye-slash icon'></i>
  )
}
export function UilEye() {
  return (
    <i className='uil uil-eye icon'></i>
  )
}
export function UilLock() {
  return (
    <i className="uil uil-lock icon"></i>
  )
}


